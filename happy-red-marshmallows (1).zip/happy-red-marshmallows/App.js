import { Text, SafeAreaView, StyleSheet} from 'react-native';

// You can import supported modules from npm
import { Div} from 'react-native-paper';

// or any files within the Snack
//import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.body}>
      <div class="navbar">
       <Image source={require('../IMAGENS/PROTOTIPO.png')} />
        <img src="PROTÓTIPO DE DESIGN.png" class="mid"></img><br></br>
        <a href="#forms">Banco de dados em windows forms</a>
        <a href="#loja">Layout de loja</a>
        <a href="#upload">Site de upload e download</a>
        <a href="#php">Banco de dados em PHP</a>
      </div>
      <div class="padding"></div>
      <div class="content">
      
      </div>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  body: {
    backgroundColor: '#70AE6E',
    color: 'white', 
    FontFamily: 'Courier New',
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
