import { Text, SafeAreaView, StyleSheet, Image} from 'react-native';

// You can import supported modules from npm
import { Div} from 'react-native-paper';

// or any files within the Snack
//import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.body}>
      <div style={styles.navbar}>
        <a href="#forms" style={styles.navbar1}>Banco de dados em windows forms</a>
      </div>
      <div style={styles.padding}/>
      <div style={styles.content}>
              <div><div id="forms"/>
              <h1 style={styles.body}>Banco de dados<br/> em windows forms</h1>
        <a style={styles.body}>Projeto de DS, possui um banco de dados interno que<br/> inclui funções de adicionar, deletar, editar e<br/> visualizar dados, além de poder adicionar imagens,<br/> guardando informações sobre IAs e seus produtores.</a> <br/>
        <a source={require('./DOWNLOADS/IA.rar')} download><button type="button" class="btn btn-primary btn-lg btn-block">DOWNLOAD</button></a>
      </div>
      </div>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  body: {
    backgroundColor: '#70AE6E',
    color: 'white',
    FontFamily: 'Courier New',
  },
    navbar: {
    overflow: 'hidden',
    backgroundColor: '#BEEE62',
    position: 'fixed',
    top: 0,
    width: '100%',
  },
  navbar1: {
    float: 'left',
    display: 'block',
    color: '#010101',
    textAlign: 'center',
    padding: '14px 16px',
    textDecoration: 'none',
  },
  mid: {
    maxWidth: '100%',
    float: 'left',
  },
  big1: {
    width: '100%',
    float: 'left',
  },
  padding: {
    padding: '10% 0% 0% 0%',
  },
  content: {
    padding: '0% 3% 5% 3%',
  },
});