import { Text, SafeAreaView, StyleSheet, Image} from 'react-native';

// You can import supported modules from npm
import { Div} from 'react-native-paper';

// or any files within the Snack
//import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.body}>
      <div style={styles.navbar}>
       <Image style={styles.mid} source={require('PROTOTIPO.png')} />
        <a href="#forms" style={styles.navbar1}>Banco de dados em windows forms</a>
        <a href="#loja" style={styles.navbar1}>Layout de loja</a>
        <a href="#upload" style={styles.navbar1}>Site de upload e download</a>
        <a href="#php" style={styles.navbar1}>Banco de dados em PHP</a>
      </div>
      <div style={styles.padding}/>
      <div style={styles.content}>
              <div><div id="forms"/><Image style={styles.big1} source={require('FORMS.png')} />
              <h1>Banco de dados em windows forms</h1>
        Projeto de DS, possui um banco de dados interno que inclui funções de adicionar, deletar, editar e visualizar dados, além da poder adicionar imagens, guardando informações sobre IAs e seus produtores. <br/>
        <a source={require('./DOWNLOADS/IA.rar')} download><button type="button" class="btn btn-primary btn-lg btn-block">DOWNLOAD</button></a>
      </div>
      </div>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  body: {
    backgroundColor: '#70AE6E',
    color: 'white', 
    FontFamily: 'Courier New',
  },
    navbar: {
    overflow: 'hidden',
    backgroundColor: '#BEEE62',
    position: 'fixed',
    top: 0,
    width: '100%',
  },
  navbar1: {
    float: 'left',
    display: 'block',
    color: '#010101',
    textAlign: 'center',
    padding: '14px 16px',
    textDecoration: 'none',
  },
  mid: {
    maxWidth: '100%',
    float: 'left',
  },
  big1: {
    width: '100%',
    float: 'left',
  },
  padding: {
    padding: '60% 0% 0% 0%',
  },
  content: {
    padding: '0% 3% 5% 3%',
  },
});